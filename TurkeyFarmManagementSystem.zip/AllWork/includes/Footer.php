<!-- Start Footer-->
	</div> <!-- End Wrapper -->
	<div class="clearfix-padding"></div>
<!-- Start Footer-->
	<footer>
		<div id="banner-wrapper">
			<div class="icon-text">
				<div class="icon-text-icon">
					<ul class="footer-nav">
						<li><a href="index.php" title="Home">Home</a></li>
						<li><a href="about.php" title="About us">About Us</a></li>
						<li><a href="product.php" title="Our Products">Our Products</a></li>
						<li><a href="Contact.php" title="Contact">Contact</a></li>
					</ul>
				</div>
				<div class="icon-text-text">
					<ul class="social">
						<li><a href="mailto:daudkandi.turkeyfarm@gmail.com"><i class="fa fa-envelope-o"></i></a></li>
						<li><a href="http://www.facebook.com/" target="_blank"><i class="fa fa-facebook"></i></a></li>
						<li><a href="https://www.youtube.com/" target="_blank"><i class="fa fa-youtube"></i></a></li>
						<li><a href="https://www.instagram.com/" target="_blank"><i class="fa fa-instagram"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
	<div class="second">
		<p>&copy; Spring 2018 CSE482.4 Project</p>
	</div>
<!-- End Footer -->
</body>
</html>