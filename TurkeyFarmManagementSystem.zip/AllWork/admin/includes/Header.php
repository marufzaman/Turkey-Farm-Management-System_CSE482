<?php
	session_start();
	if(isset($_SESSION['id'])){
		$userName = $_SESSION['id'];
		include('config.php');
		$sql = "SELECT a_last FROM admin WHERE a_user = '$userName' ";
		$result = $conn->query($sql);
		if ($result->num_rows >0 ) {
			while ($row = $result->fetch_assoc()) {
					$name = $row['a_last'];
			}
		}

	}
	else{
		header("Location: ../index.php");
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/jquery.bxslider.css" rel="stylesheet" />
	<link href="style.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet"/>
	<link rel="shortcut icon" href="img/icons/favicon.png"/>
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  	<script src="https://code.jquery.com/jquery-3.1.1.js"></script>
  	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>